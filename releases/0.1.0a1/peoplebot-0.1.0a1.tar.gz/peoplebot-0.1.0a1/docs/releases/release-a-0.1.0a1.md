# PeopleBot release candidate A — 0.1.0a1

Status: prepared alpha release candidate pending read-only review, integration, and
separate publication authorization. It is not a published release or a functioning
general Architect or project-task agent.

## Candidate identity and artifacts

The source-of-truth candidate is one exact clean Git commit in
`peoplebot-framework/peoplebot`. The adjacent generated candidate-evidence JSON
records that full commit, build tools, artifact filenames, byte sizes, SHA-256
digests, and archive inventories. The commit is intentionally not embedded in its
own source tree.

The proposed artifacts are:

- `peoplebot-0.1.0a1-py3-none-any.whl`, the installable Python wheel;
- `peoplebot-0.1.0a1.tar.gz`, the corresponding source distribution; and
- `peoplebot-0.1.0a1-candidate.json`, the local review evidence that binds both
  artifacts to exact source State.

The wheel contains the `peoplebot` and `peoplebot.adapters` packages, the versioned
Adapter JSON configuration, and both `LICENSE` and `LICENSING.md` under installed
license metadata. The source distribution additionally contains tests, relevant
configuration, contracts, this release note, the Instance-memory example, and the
separate-environment alpha plan. Git administration, credentials, local runtime
memory, Execution evidence, temporary workspaces, caches, and build directories are
not package inputs.

## Install and retrieve corresponding source

Use Python 3.11 or newer. Git 2.45 or newer is required for Git-backed operations;
the Windows admission implementation is Windows-specific. This candidate is tested
on the precise Python, Git, pip, build-frontend, setuptools, and wheel versions in
the candidate-evidence JSON. Other declared Python versions are not certified by
that one validation run.

Verify the wheel SHA-256 against the adjacent candidate evidence, then install the
exact file without resolving runtime dependencies:

```text
python -m pip install --no-deps <artifact-directory>/peoplebot-0.1.0a1-py3-none-any.whl
peoplebot --help
python -m peoplebot --help
```

Retrieve corresponding source from the adjacent
`peoplebot-0.1.0a1.tar.gz`, whose digest and inventory are recorded in the same
evidence. For Git-based inspection, fetch the canonical repository and detach at the
full `source_commit` recorded there; a branch or release label is not exact State.

## Usable utilities and demonstrations

`peoplebot resolve-state` is a deterministic utility for resolving an exact local
Git State. The context, admission, provenance, memory, synchronization, and recovery
APIs remain experimental utilities with the documented v0 limits.

`alpha-setup`, `alpha-adopt`, and `alpha-resume` are trusted synthetic fixture
demonstrations. Fixture A and B are not PeopleBot package versions, and successful
fixture adoption does not prove that arbitrary PeopleBot upgrades are compatible.
This candidate provides no general update service, release discovery, automatic
migration, package installer, or project-task workflow.

## Consuming-environment boundary and limitations

A consuming sovereign environment owns its Instances, memory, project history,
GitHub identity and repositories, Codex runtime/authentication, credentials, and
website history. Those resources do not belong in PeopleBot development. PeopleBot
is consumed only as an explicitly pinned framework dependency and reviewed update.

NormsExchange remains a separate project and environment. No NormsExchange folder,
Instance, memory branch, credential, repository, or runtime is included in or
created by this candidate.

Before the first supervised project task, separate authorization and evidence are
still required for release publication/adoption, a separately provisioned consuming
environment, real GitHub runtime-memory transport using externally managed
credentials, and a bounded project-task Adapter. Messaging, schedules, UI,
automatic learning, and general migration remain outside this candidate.

## Proposed publication after acceptance

After ChatGPT accepts the exact candidate commit and Ray separately authorizes
integration and publication:

1. fast-forward `main` to the exact `source_commit` in the candidate evidence;
2. create the annotated tag `v0.1.0a1` at that same commit;
3. create a GitHub prerelease titled `PeopleBot 0.1.0a1`;
4. attach the exact wheel, source distribution, and candidate-evidence JSON; and
5. verify the tag, release assets, sizes, and SHA-256 digests independently.

The canonical repository is currently private. The default proposal keeps the
candidate private, so only authorized collaborators can retrieve it. Any public
distribution or repository visibility change requires a separate explicit decision
after reviewing the source artifact's contents and GPL-3.0-only obligations. No tag,
release, asset upload, or visibility change is authorized by this document.
