# PeopleBot release candidate A correction — 0.1.0a2

Status: prepared correction candidate pending private review and separate public
publication authorization. It is not a published release and does not create a
functioning Architect or project-task agent.

## Correction

This candidate removes consuming-project-specific documentation from the proposed
public package and makes the adoption boundary explicitly project-neutral. Future
source distributions exclude repository working instructions, private project
state, historical handoffs, and consuming-project planning. Generic sovereign-
environment requirements now live in the public
[`sovereign-environment-adoption-v0`](../contracts/sovereign-environment-adoption-v0.md)
contract.

The correction changes documentation, package versioning, and source-distribution
selection only. Runtime modules, schemas, defaults, configuration, and test fixtures
are unchanged from the accepted `0.1.0a1` implementation.

## Candidate identity and artifacts

The source-of-truth candidate is one exact clean Git commit in the canonical
PeopleBot repository. Adjacent private evidence records that full commit, build
tools, artifact filenames, byte sizes, SHA-256 digests, archive inventories, and
validation. The source commit is intentionally not embedded in its own source tree.

The proposed artifacts are:

- `peoplebot-0.1.0a2-py3-none-any.whl`;
- `peoplebot-0.1.0a2.tar.gz`;
- a public-safe provenance record; and
- `SHA256SUMS` covering the wheel, matching source, and public provenance.

The original private candidate evidence remains private because it contains
machine-specific build details.

## Capabilities and limits

The wheel provides the accepted experimental Git-native State, context, admission,
provenance, Instance-memory, synchronization/recovery, bounded read-only Adapter,
and synthetic alpha utilities. It adds no runtime dependencies.

The synthetic alpha commands prove trusted local mechanics only. They do not
discover or install releases, provision a consuming environment, create a project
agent, transfer credentials or authority, invoke a project-task model, or implement
general migration, messaging, schedules, UI, or automatic learning.

All consuming-project identities, repositories, credentials, paths, Instances,
memory, communications, and task context are supplied and owned by the consuming
sovereign environment. See the public adoption contract and each utility's specific
v0 contract before use.

## Install and inspect matching source

Use Python 3.11 or newer. Git-backed operations require Git 2.45 or newer; the v0
single-Execution admission implementation is Windows-specific. Verify artifact
digests first, then install the exact wheel without dependency resolution:

```text
python -m pip install --no-deps ./peoplebot-0.1.0a2-py3-none-any.whl
peoplebot --help
python -m peoplebot --help
```

The matching source is `peoplebot-0.1.0a2.tar.gz`. Public consumers need no access
to private development history to inspect it. PeopleBot is licensed
`GPL-3.0-only`; both `LICENSE` and `LICENSING.md` are included.

## Publication boundary

Building and privately reviewing this candidate does not authorize a public commit,
tag, release, asset upload, edit to an earlier release, deletion, or history
rewrite. Those actions require separate explicit authorization after review.
