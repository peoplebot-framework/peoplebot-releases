# PeopleBot V2 Project State

Status: GPLv3-only project with a documentation-only founding State plus experimental deterministic State/Execution, context-preparation, context-assembly, Windows Instance-admission, local admission/Execution provenance, one bounded read-only Codex Adapter, accepted bounded local Instance-memory checkpoint/resume and synchronization/recovery, an accepted synthetic deterministic alpha setup/compatible-adoption experiment, and unintegrated release-candidate packaging on `codex/release-a-packaging`.

This document separates settled requirements from implementation proposals and unresolved choices. It is the concise retrieval surface for the current architecture. The complete planning source is preserved at `docs/planning/PEOPLEBOT_V2_CODEX_REBUILD_HANDOFF.md` and should not be loaded into every future Execution.

## Settled requirements

### Scope and substrate

- V2 is a clean rebuild. V1 is historical and must not be inspected, imported, migrated, modified, or used for design guidance.
- Git is the principal durable substrate for State, history, lineage, provenance, isolation, synchronization, and recovery.
- Known information is resolved by deterministic software. AI is used where inference is required.
- Provider context is disposable cache; Git-backed State is authoritative.
- Framework complexity must earn its existence through measurable benefit.

### Five primitives

- **Blueprint:** a reusable agent type defining durable behavior and configuration.
- **Instance:** one concrete agent created from a Blueprint and hosted by a sovereign environment.
- **State:** an exact repository snapshot identified by repository identity plus full Git commit, with an optional path selecting an artifact.
- **Message:** a small, actionable, normally append-only object referencing exact State and artifacts.
- **Execution:** one bounded run of an Instance from pinned starting State to resulting State or a recorded terminal outcome.
- Roles are metadata or Blueprint/Instance descriptions.
- Adapter is thin runtime infrastructure, not a sixth primitive.
- Environment is the sovereign hosting and ownership context, not a core primitive. One environment may host multiple Instances and Executions.

### Instance identity and environment ownership

- Each sovereign environment owns its GitHub identity, repositories, and Instances. Only the owning environment executes an Instance and advances that Instance's canonical State.
- Copying an agent into another environment creates a new Instance. The new Instance may reuse the Blueprint and selected authorized procedures or context with exact provenance, but credentials, permissions, private context, and standing authority do not transfer automatically.
- Live Instance migration is outside the initial version.
- The intended user-facing actions are **Create agent**, **Copy agent**, and **Run agent**. Their interface is not implemented.
- The first NormsExchange alpha must run in a separate sovereign environment with its own GitHub identity/repositories, separately configured Codex runtime and authentication context, Instance identities, memory, project history, and credentials. It consumes a pinned PeopleBot release as a dependency; no NormsExchange Instance or project memory belongs in the PeopleBot development environment.
- A new environment may start with any supported agent type. Architect is the preferred setup default, not a mandatory dependency for every run. Bootstrap uses a pinned PeopleBot release, reviewed Blueprint States, and deterministic versioned setup commands rather than conversation reconstruction.

### Supervised alpha and synchronization

- Manual launch, explicit context selection, explicit checkpoint content, and manually invoked tested synchronization/update commands are acceptable for the first usable alpha.
- Alpha synchronization is implemented behavior, not an ad hoc Git push: it targets an explicitly configured owning repository and exact refs; verifies remote results; distinguishes local-only, remotely verified, failed, and uncertain outcomes; preserves local progress; refuses conflicts without overwrite; and reconciles uncertain outcomes before retry.
- Fresh-checkout recovery occurs in the same owning environment after the original Execution has stopped and must not enable a second live Execution.
- Framework distribution/adoption is separate from Instance-memory synchronization. Executions retain pinned versions until completion; compatible adoption preserves Instance identity and memory; incompatible change requires explicit migration; and update failure preserves the prior usable State.
- Before broader onboarding, demonstrate release A installation, Instance creation, progress save/synchronization, compatible release B adoption, and resume of the same Instance with intact memory.
- A single-Instance synchronization attempt must explicitly bind repository, environment, Instance, Blueprint, exact local memory State/ref, one resolved authorized push destination/ref, expected remote State or absence, bounded limits, and a pinned authorized baseline with its reachable history. Later memory commits must remain in the supported non-merge lineage; names, privacy, and current-tree contents confer no publication authority.
- Only the selected Instance-memory ref is synchronized in this slice. Admission and terminal-evidence refs remain local, so memory synchronization is not a complete Execution-history backup.
- Timeout or disconnect can follow remote publication. Such an attempt remains uncertain until explicit reconciliation: the attempted commit proves only the current observed ref value; the prior value does not prove publication never occurred; an intervening value requires deliberate reconciliation; unavailable inspection remains uncertain. No automatic retry follows.

### Instance-owned memory and decisions

- A Blueprint is a reusable agent type. It does not own one person's or one task's memory.
- Each Instance owns its authorized context, decisions, progress, and learned procedures in State controlled by its sovereign environment and associated with that Instance's identity-specific lineage.
- An Instance may autonomously save useful authorized work at meaningful boundaries without requesting repeated approval. Meaningful boundaries include milestones, decisions, reusable lessons, handoffs, and expensive work that would otherwise require substantial reconstruction.
- A save is first a local Git commit; remote push is a separate synchronization boundary. Neither a local commit nor the current local Execution-evidence refs imply GitHub synchronization.
- Routine Instance saves do not require a Blueprint update. The framework architect remains the sole framework/Blueprint maintainer by default, and shared maintenance happens only when explicitly requested or delegated.
- Explicit bounded Instance checkpointing and manually invoked synchronization/recovery have accepted experimental Git implementations. Automatic checkpoint decisions and automatic synchronization are not implemented. Exact triggers, long-term storage layout, push policy, and broader failure recovery remain implementation choices.

### Execution admission and identity-specific State

- One active Execution is permitted per Instance. Every launch path within the owning environment must use the same atomic admission mechanism.
- An additional request while the Instance is active exits immediately with a classified outcome such as `instance.already_running`. It invokes no model and performs no waiting, polling, queueing, or automatic retry.
- Parallel agents of the same type are separate Instances. Each Instance retains context and progress on an identity-specific branch; concurrent-execution branches within one Instance are unnecessary under this rule.
- Branch names identify storage locations. They do not establish authority or enforce permissions.
- Execution ownership is released only after execution has actually stopped. Recording finish, failure, or yield must not permit overlapping activity.
- After interruption, preserve recoverable State and establish that the previous execution cannot continue before admitting another. Timer expiry alone is insufficient proof.

### Framework and Blueprint maintenance

- The framework architect is the only framework/Blueprint maintainer by default. Ray starts it manually; there is no default scheduled run, daily automation, background review, or automatic architect invocation.
- Framework/Blueprint maintenance authority is off by default for new agent types and may be explicitly delegated later.
- Ordinary agents autonomously maintain their authorized task State, context, and learned procedures. They may record improvement proposals, but proposals do not automatically trigger architect work and a normal run does not require Blueprint rewriting or review.
- On a requested Blueprint update, the architect examines relevant Instance changes and follows deeper references when useful rather than routinely rereading complete histories.
- Common general improvements belong in the Blueprint. Specialized procedures, private knowledge, task-specific context, and Instance histories remain separately addressable instead of being merged wholesale into shared State.
- Active executions retain their exact adopted versions. Compatible validated updates may be adopted at execution boundaries; incompatible updates require an explicit migration procedure.
- Any later delegation to multiple maintainers retains a designated integration owner for each shared framework destination.
- The upstream Architect maintains PeopleBot releases. A local Architect maintains only its authorized environment and local Blueprints, deliberately adopts reviewed updates, and has no automatic upstream write authority. Architect runs are manual by default; ordinary agents have no framework/Blueprint maintenance authority unless explicitly delegated.
- An owner may explicitly choose an independent framework fork while preserving canonical origin, applicable license notices, recorded divergence, and compatibility checks. Ordinary task instructions cannot silently fork the framework.

### Shared publication and external-effect recovery

- Owner-publishes/authorized-peers-read messaging remains authoritative; replies are published in the replying environment's repository.
- Multiple Instances may compose messages, but their environment deterministically serializes publication to its canonical outbound branch.
- Preserve request identity and recorded outcomes so completed requests are not silently executed twice.
- Reconcile uncertain external effects before retrying. Git rollback does not undo an external action.
- Git integration, structured records, explicit ownership, and exact references implement these boundaries. Agent names, branch names, and prose do not establish authority or execution status.

These are settled architectural requirements. A bounded Windows admission experiment implements the single-active-Execution gate for synchronous in-process task code. A follow-on experiment commits rejected or admitted-start observations and exact terminal Execution records on isolated local Git refs without giving records control of the live lock. Copying, migration, messaging publication, external-effect recovery, Blueprint maintenance workflows, and the Create/Copy/Run interface are not implemented yet.

### Execution and provenance

- Resuming later creates a new Execution even when the larger task continues.
- An Execution records the responsible Instance; actual adopted Blueprint; versioned runtime Adapter; exact procedure commits; relevant input Messages and State; starting State; produced artifacts; resulting State or terminal outcome; available usage observations with source and confidence; and reusable learning.
- Mutable branches, logical names, founding commits, and release labels do not substitute for the exact commits actually used.
- Git commits are the durable execution and recovery boundaries. Useful partial work is committed when an Execution completes, blocks, yields, precedes a risky transition, or would otherwise require meaningful re-reasoning to recover.

### Knowledge evolution

- A learned procedure has a stable logical identity and a lasting Git lineage.
- Extend the currently adopted procedure lineage by default.
- When conditions change, retain all still-valid knowledge and reason about the changed or unknown portion.
- Create a separate knowledge lineage only for genuine divergence, not merely because an Execution uses a temporary branch or worktree.
- Preserve ancestry when a knowledge lineage diverges.
- Permit deliberate reconciliation or merging of compatible reusable improvements.
- Every Execution pins the exact resolved procedure commit it used.
- Temporary Execution branches and worktrees provide bounded isolation and integration readiness; they are not themselves lasting knowledge lineages.
- The precise mechanism for deciding whether change extends, diverges, or later reconciles remains an implementation choice.
- Blueprint and procedure adoption is deliberate. Upstream discovery never silently changes an Instance.
- Adoption, sharing, or forking does not transfer credentials, private memory, transcripts, private reasoning, private operational history, or standing authority.

### Context, artifacts, and adapters

- Models receive only context relevant to the current Execution.
- Complete appropriate tool output is retained as an addressable artifact within its permitted privacy and access boundary; models receive targeted slices.
- Runtime Adapters deterministically map neutral Execution semantics to a runtime, prepare invocation inputs, invoke the runtime, and normalize results.
- Adapters do not discover State or define agent architecture and are themselves versioned, addressable State.

### Sovereign messaging

- Every sovereign environment owns its GitHub identity and dedicated outbound messages repository.
- Multiple Instances may publish through the owning environment's store while preserving responsible Instance and Execution identity.
- Authorized peers read an environment's messages; replies are published in the replying environment's repository.
- Job-specific communication repositories retain sovereign ownership and owner-publishes/authorized-peers-read semantics.
- Participation configuration remains small and local. There is no global communication directory by default.
- Access denial is a concrete blocked or failed condition. PeopleBot does not hunt for credentials, renegotiate permissions, or retry indefinitely.

### Efficiency, stopping, and usage

- Use local Git heavily and synchronize remotely only at meaningful boundaries.
- Use Git-native branches and worktrees for concurrent isolation and normal Git integration for reconciliation.
- Stop or yield on known unresolved conditions rather than polling or re-analyzing indefinitely.
- Each environment maintains Git-backed local usage/capacity State.
- Usage data records its source and confidence and distinguishes provider-reported, locally estimated, and unknown measurements.
- Unavailable values are never invented. Provider activity outside PeopleBot remains a stated uncertainty where relevant.
- Surplus expiring capacity may support bounded improvements that create durable value after protecting foreground work.
- Active best-effort capacity policy: continue useful authorized work toward approximately 80% of the supported five-hour allowance used, then stop substantive expansion and use approximately 20% to reach a manageable validation, checkpoint, synchronization, and report boundary. Check supported usage at meaningful boundaries; stop earlier for completion, a real blocker, insufficient reserve, or a weekly/platform limit. This is a usage target rather than elapsed-time quota, can lag or be crossed by one bounded operation, and never justifies invented work, repeated unchanged tests, reset polling, scheduled restarts, background loops, extra accounts, model switching, or additional agents. When telemetry is unavailable, report it unknown and use bounded milestones.
- Interpret usage readings by their reported limit/window identity and reset time. A genuine refill or reset starts a newly available allowance: continue the already authorized work toward the new window's approximate 80% target instead of stopping because the earlier window was near its boundary. A lower percentage alone is not proof of refill when the source or window cannot be established. Do not wait or poll for a reset; stop for completion, blockers, reserve needs, or applicable weekly/platform limits.

### Origin and project direction

- PeopleBot is licensed under GNU GPL version 3 only (`GPL-3.0-only`). Commercial use and forks remain permitted under its terms.
- The central creator acknowledgment, dated release-coverage declaration, canonical origin, evidence limits, and scope boundaries are in `LICENSING.md`.
- Exact Git provenance, applicable notices, and contributor attribution must be preserved.
- Contribution sign-off and trademark policies remain unsettled; no CLA, DCO, assignment, registration, or name-clearance claim has been adopted.

### Continuation protocol

- At start or resumption, derive repository identity and exact working State from Git, then read `AGENTS.md`, this concise state, and only task-relevant linked contracts or procedures.
- Before editing, give a brief context readback naming the goal, full starting commit, settled decisions, open questions, bounded action, and supporting repository paths. It is not a new approval gate.
- At meaningful completion, block, or yield, update this compact surface with results, remaining issues, work branch, and next action; commit useful authorized progress and synchronize at meaningful boundaries.
- Keep accepted `main` distinct from unintegrated work-branch State. Derive a commit's identity from Git rather than attempting to write that commit's own hash into itself.
- Discover knowledge by stable path or logical identity, pin the full commit actually used, and adopt upstream changes deliberately. Extend the adopted lineage by default, preserve valid knowledge, and reserve divergence for genuine incompatibility.
- Promote reusable learning into the relevant contract or procedure and regression tests. A temporary Execution branch does not create a new lasting knowledge lineage.
- Retrieve targeted references and relevant deltas. Do not routinely reload the complete planning handoff, instruction prompts, raw transcripts, or full history.
- On access failure, preserve local progress and report the exact boundary without indefinite retries, secret searches, project recreation, or asking Ray to reconstruct committed decisions.
- Git commits preserve committed State; they do not automatically back up uncommitted index or working-tree content.

### Development and review workflow

- ChatGPT performs discussion and read-only review. Review findings distinguish directly reproduced failures, source-inspection findings, and suspected risks; each material finding states the concrete failure scenario and evidence available.
- Codex performs approved implementation, regression tests, validation, commits, and repository synchronization. It corrects demonstrated failures without silently broadening the milestone.
- ChatGPT then reviews the exact pushed commit read-only before any integration instruction. A work branch being pushed or marked review-ready is not acceptance and does not change `main`.

## Founding implementation proposals

These are proposals, not settled architecture:

- Use this repository as the canonical PeopleBot framework repository.
- Keep the founding commit documentation-only.
- Implement the first executable proof as a small deterministic State-reference and Execution-record vertical slice, tested against temporary local Git repositories before introducing a production runtime Adapter or messaging transport.
- Prefer conventional, dependency-light tooling until a concrete need justifies more machinery.

## Current experimental implementation choices

These choices implement the first bounded proof and are not universal architecture requirements:

- Python 3.11 or newer, using only the standard library and installed Git CLI.
- `StateRef` with opaque repository identity, lowercase full 40-hex commit, and optional canonical relative POSIX Git path.
- Local commit/path resolution using Git 2.45+ controls that neither consults mutable branches or working-tree content, nor accepts replacement refs or ambient repository/config routing, nor lazily fetches missing objects.
- `ExecutionRecord` with exact Blueprint, Adapter, procedure, input, artifact, learning, starting-State, and result-State references where applicable.
- Explicit terminal outcomes for blocked/failed work and explicit source/confidence for usage observations.
- A blocked/failed Execution may preserve one recoverable partial commit as an exact repository-level artifact reference while retaining null `resulting_state` and its truthful terminal status.
- UTC timestamps use a strict extended RFC 3339 subset with required seconds and zero through six fractional digits; unsupported precision and alternate ISO forms are rejected.
- Stable compact UTF-8 JSON with sorted keys and a trailing newline, labeled as experimental `v0` rather than a settled public schema.
- A temporary implementation branch is used for this Execution; it is not a lasting procedure/knowledge lineage.
- Detached worktree preparation accepts repository-level pinned State and a nonexistent destination, registers the exact commit with `--no-checkout`, and reports that no working files were materialized.
- Preparation preserves local-only resolution controls, disables hooks for the registration command, and performs no checkout-time filtering or submodule work.
- An explicit path-specific policy State supplies bounded entry, per-blob, total-byte, and path-exclusion decisions; no relevance inference or general dependency traversal occurs.
- Context manifests are deterministic metadata derived from pinned Git trees and locally available objects. They contain no machine paths, timestamps, or context content.
- Context assembly reuses that manifest selection to read complete valid UTF-8 regular/executable blobs from pinned local objects. It preserves source bytes, embeds exact blob/path provenance and exclusions, never creates a worktree or fetches, and classifies unsupported content.
- Context assembly still accepts caller-supplied repository identity and policy values. It neither authenticates the checkout's external identity nor independently verifies supplied policy content against the referenced policy artifact.
- Instance-memory v0 accepts only explicitly supplied canonical-path UTF-8 items: at most 64 items, 65,536 bytes each, 262,144 content bytes total, and 65,536 generated metadata bytes. It never scans the checkout or decides what to remember.
- One deterministic `refs/heads/peoplebot/instances/v0/<environment-digest>/<instance-digest>` discovery ref identifies local storage for an environment/Instance. Exact saved State remains the full commit; metadata binds repository, environment, Instance, adopted Blueprint State, ref, and item blob identities/digests.
- Initial creation is explicit and requires an absent destination. Later publication requires the exact previous memory State. The existing prepared reference transaction guards object value and direct-ref identity; stale, symbolic, mismatched, or indeterminate destinations are preserved and classified.
- Changed memory creates a child commit. Equivalent meaningful content verifies the expected direct ref and returns the same State without a new memory commit, while its Execution still receives independent provenance. Memory publication and terminal-evidence publication remain separate; a successfully attached memory State is retained and reported if terminal persistence fails.
- Exact resume validates repository, environment, Instance, and Blueprint binding, then retrieves only explicit items through the existing bounded local context assembly. It creates no worktree, fetches no object, and does not restore hidden model state.
- The memory operation uses existing admission/provenance, object-resolution, and Git-plumbing protections. It does not modify working files, index, checked-out branches, main, Blueprints, or another Instance. Runtime memory always reports `remote_synchronized: false`; pushing the framework implementation branch is not Instance-memory synchronization.
- Synchronization v0 explicitly binds one canonical Instance-memory ref, pinned local memory State, authorized baseline/history, expected remote State or absence, configured remote, exact push destination, and bounded limits. It rejects effective Git URL rewrites, multiple push URLs, credential-bearing destinations, mirror/receive-pack overrides, source movement, unsupported ancestry, and remote mismatch before publication.
- Every post-baseline commit must be one direct non-merge memory descendant whose strict canonical metadata reconstructs its complete root tree. Item modes, identities, byte sizes, UTF-8 content, and SHA-256 digests must match; undeclared paths, links, gitlinks, malformed metadata, and hidden historical content are refused. The explicitly authorized baseline and its ancestors are not required to be memory-only trees.
- Exact publication uses one normal explicit refspec with hooks, tags, default/wildcard/mirror behavior, and automatic submodule pushes disabled. Only the selected memory ref is synchronized; local attempt/terminal evidence and unrelated refs remain local. Remote preflight is not an atomic concurrency guarantee.
- Sanitized local companion evidence preserves explicit remote-verified, failed, or uncertain observations separately from Execution-record construction. A timeout, disconnect, prior observation, or unavailable verification never causes automatic retry or a false claim that publication did not occur.
- Recovery v0 runs through the same Instance admission boundary, fetches only the authorized ref's objects without updating a local destination, tracking refs, tags, submodules, or `FETCH_HEAD`, validates exact lineage/tree/binding, and guardedly creates or fast-forwards the canonical local memory ref. Dangling or resolved symbolic, checked-out, newer, conflicting, ambiguous, replaced, or competing State is retained and classified without changing working files, index, registrations, unrelated refs, or the remote.
- The existing prepared native Git transaction implementation now groups exact multi-ref transitions: claim owner while quarantine is absent; attach quarantine while owner remains exact; publish canonical State while owner, quarantine, and expected canonical value remain exact; and remove owner/quarantine together while canonical State remains exact. A mismatch aborts the complete grouped transition.
- Uncertain recovery is never retried automatically. Deliberate continuation must name the same operation, match its exact deterministic owner marker, and find an absent quarantine ref or the exact expected State; any other retained identity or value is preserved and refused.
- Recovery reporting preserves independently established facts. A late record failure keeps a verified recovered State as an exact partial-State artifact with failed status and null `resulting_state`; an unavailable record leaves returned recovery and incomplete start evidence separate. Actual recovery refs are reported retained, absent, or unknown rather than inferred from an exception.
- Git transport lifetime reuses the bounded direct-process and pipe-worker owner. Normal completion requires the direct Git process and inherited output pipes to close; a pipe-holding helper retains admission and exact in-process recovery authority. Detached helpers that shed those pipes, abrupt owner-process death, and remote-side cancellation are outside the v0 proof.
- Native local ref transactions protect their exact grouped transition, not the intervals between transitions. Instance admission serializes ordinary supported PeopleBot recovery; direct external Git mutation can still race between transitions and is not comprehensively prevented, authenticated, or treated as another admitted Execution.
- Changed or initial memory publication refuses a destination branch selected by any structured Git worktree record, including an unborn linked `HEAD`; inspection ambiguity fails closed. Unchanged memory may verify the same expected object without changing checkout surfaces. This coordinated preflight does not eliminate a concurrent external checkout race and does not manage or repair worktrees.
- If terminal-record construction fails after memory was saved, any constructible failed record keeps `resulting_state` null and identifies the exact checkpoint as its recoverable partial-State artifact. If record construction remains impossible, the returned checkpoint and classified record failure remain separate evidence.
- Windows Instance admission uses a nonblocking one-byte `msvcrt` lock on one stable digest-addressed file beneath an explicitly supplied absolute runtime root. It directly locks byte zero beyond end-of-file, so a new file remains empty and no pre-lock initialization can conflict with its owner; existing nonempty resources remain usable. The exact owning descriptor is retained for a synchronous callback and released in `finally`; live locks, PIDs, and running flags are not committed or synchronized.
- A contender for the same environment/Instance returns `instance.already_running` before task code. Different Instances use independent resources. Routine release never deletes the resource, and a stale handle cannot release a later descriptor.
- Live admission handles prohibit shallow copy, deep copy, and serialization. An identity or copied descriptor number cannot reproduce ownership, and descriptor reuse after release cannot give a stale object control over a newer owner.
- After abrupt termination of the lock-owning process, successful OS-lock reacquisition proves only that admission is available for the supported in-process lifetime. It does not prove completion, create a terminal Execution outcome, or make external effects safe to retry.
- Admission/Execution provenance accepts exact pre-task inputs and writes one isolated `refs/peoplebot/attempts/v0/<digest>` lineage per attempted Execution. The attempt commit is parented by starting State; admitted terminal evidence is an existing `ExecutionRecord` in a child commit.
- Rejection records relevant exact inputs and `instance.already_running` but runs no task and creates no terminal Execution. Admitted task code starts only after its start evidence commits. Terminal evidence is written while the exact live admission handle remains held.
- Start evidence alone is explicitly incomplete. Task failure, terminal-record production failure, Git persistence failure, and admission-release failure remain distinct returned observations; there is no automatic retry or inferred completion.
- Evidence writes use local Git plumbing with replacement objects, lazy fetch, hooks, and content filters disabled. They never check out or change working files, the index, or branches. Initial and terminal publication prepares and locks the exact attempt ref, verifies expected object state, checks symbolic-ref identity under that lock, and refuses overwrite, movement, symbolic redirection, or an indeterminate identity without changing the symbolic ref or its target. An inspection error is not a negative finding: mutation requires the specific successful observation that establishes eligibility, and unknown state preserves existing resources.
- Every normal task return is validated. `None` or another invalid type is a classified record failure that preserves incomplete start evidence, creates no terminal record, does not repeat the callback, and does not prevent truthful admission release.
- Returned in-process observations, exact locally committed path-specific evidence States, movable discovery refs, and remote synchronization are distinct. This slice does not push, and successful local persistence reports `remote_synchronized: false`.
- Directory requests expand to tracked leaves; explicit request overlap is deduplicated. Symlinks are unfollowed blobs and gitlinks are unfetched commit references.
- Cleanup is limited to the operation-owned exact detached registration. It verifies both sides of the current Git linkage, the identity-bound ownership marker, and unchanged per-worktree administrative/index state; it refuses user, staged, moved, replaced, or uncertain state and reports recoverable remnants.
- Preparation establishes that the initial administrative state is disposable before baselining it. Unexpected entries or staged differences are refused and preserved; a clean index matching pinned State is accepted.
- The first Adapter experiment loads an immutable canonical configuration snapshot from exact Adapter State. It proves that the pinned driver source matches both the source file observed when the module was imported and the current source file; it does not claim that executing Python objects or bytecode have an independently verified identity. It distinguishes canonical configuration, source-blob, and driver digests, assembles only pinned `LICENSING.md`, validates a small exact factual response, renders explanatory wording deterministically in software, and returns a truthful `no_change` or failed Execution through the admission/provenance lifecycle.
- Prompt delivery, stdout/stderr draining, and process execution share one monotonic deadline. Ownership begins immediately after successful child creation, before worker construction or startup. The direct process and only those non-daemon I/O workers that actually started are one owned lifetime; timeout, overflow, partial setup, interruption, and I/O errors require confirmed process termination and started-worker joins before admission release. The exact invocation workspace remains operation-owned until removal succeeds. If child/worker cleanup cannot be established, exact in-process process/workspace recovery authority and admission remain retained. After one workspace-removal failure, the retained handle refuses all later deletion attempts: its path is recovery information for deliberate manual inspection, not authority over replacement or newly added contents. A retained directory alone does not keep admission after child and workers are confirmed stopped. This does not cover abrupt owner-process death, remote inference cancellation, or detached descendants.
- Captured output within existing bounds is parsed before a completed invocation reports workspace-cleanup disposition. Independently valid provider usage survives a later workspace-removal failure in both the Adapter observation and terminal Execution evidence, while the cleanup failure remains an explicit failed outcome and no invalid answer is accepted.
- Sanitized Adapter observations retain validated structured facts and software-rendered wording, exact context/configuration/blob/driver/response identities, observed process disposition, and actually available usage. The observation is a companion blob in the same terminal evidence commit, whose parent graph also keeps the local Adapter State reachable. Raw JSONL, provider thread identity, diagnostics, credentials, machine-specific authentication paths, and transcripts are not retained.
- The runtime child receives a documented minimal environment plus the explicitly supplied externally managed Codex home. Prompt wording does not prevent tool behavior; supported event inspection detects and rejects observed tool/unknown events after execution, so stronger prevention remains required before another live call.
- Synthetic alpha setup records one exact framework selection in an environment-owned root commit with no PeopleBot-development parent. That commit is the explicit baseline for the Instance-memory lineage; repeating identical setup in another isolated compatible Git repository produces the same exact State.
- Compatible fixture adoption is an admitted Execution. It requires distinct descendant framework State plus unchanged exact Blueprint and interface-anchor blobs and fixed regular-file paths; it validates locally before an expected-State-guarded selection update. The exact adopted Blueprint remains pinned to A, and missing, incompatible, busy, or pre-publication failure paths preserve A and memory.
- Fresh-process alpha resume revalidates the recorded objects, assembles only explicitly requested memory from exact State, loads the exact selected fixture source blob, and reports source and memory identities/digests. This trusted synthetic proof is not a general release updater, code sandbox, hostile-process attestation, or real GitHub/environment-isolation demonstration.

The contracts and exclusions are documented in `docs/contracts/state-execution-v0.md`, `docs/contracts/context-preparation-v0.md`, `docs/contracts/context-assembly-v0.md`, `docs/contracts/instance-admission-v0.md`, `docs/contracts/execution-provenance-v0.md`, `docs/contracts/read-only-adapter-v0.md`, `docs/contracts/instance-memory-v0.md`, `docs/contracts/instance-memory-synchronization-v0.md`, and `docs/contracts/alpha-bootstrap-v0.md`.

## Unresolved choices

- Exact long-term schemas, paths, identifier grammar, dependency-reference encoding, and State granularity; the current `v0` record is experimental.
- Long-term implementation language and packaging; Python is selected only for the current bounded proof.
- Relevance inference, dependency-aware context projection, generated/dependency noise classification, and model-ready prompt composition beyond explicit UTF-8 blob assembly.
- General Adapter contract and portability, dynamic model/runtime selection, enforceable tool prevention and remote cancellation, and provider usage fields not emitted by the chosen interface.
- Independent executing-code/bytecode identity verification beyond the current source-at-import and current-source-file evidence.
- Message identifiers, cursors, deduplication, acknowledgements, retries, and delivery/readiness evidence.
- Temporary Execution branch creation, file materialization, branch/worktree naming, integration checks, and broader recovery details.
- Artifact placement, retention, privacy boundaries, and sanitized learning promotion.
- Long-term stopping heuristics, model selection, escalation thresholds, and scheduling beyond the active best-effort capacity policy.
- Empirical evaluation design, including how to test the approximate 80% model-resource reduction hypothesis.
- Promotion and adoption criteria for shared procedures and Blueprint revisions.
- Contribution sign-off policy, trademark policy, and any future contributor workflow.
- Historical inventory and licensing-authority evidence for intended pre-V2 coverage.
- Cross-process coordination and manual recovery for refused or interrupted worktree disposal.
- Admission portability beyond tested Windows; long-term runtime-root provisioning and access controls; and asynchronous, background-thread, child-worker, and remote-operation lifetimes.
- Long-term admission/Execution evidence schema and ref naming; retention and explicit remote synchronization of isolated attempt refs; interrupted-attempt reconciliation; and policy for incomplete start evidence. Durable evidence remains non-authoritative over live locks.
- Autonomous Instance-memory checkpoint triggers, retention, long-term ref/schema encoding, Blueprint-adoption transitions, remote synchronization policy, and deliberate reconciliation after interrupted or competing publication.
- Long-term memory-sync destination/authentication configuration, remote-base policy beyond explicit v0 authorization, and whether/when isolated Execution-evidence refs are separately synchronized.
- Concrete copy workflow, live-migration policy beyond the initial exclusion, and Create/Copy/Run interface design.
- Blueprint update/migration records and deterministic outbound-message serialization details.

## Current repository condition

- Founding documentation/configuration plus dependency-free deterministic State/Execution, context-preparation, context-assembly, Windows Instance-admission, local admission/Execution provenance, and the accepted purpose-specific read-only Adapter.
- Detached worktree registration, deterministic context manifests, and explicit useful UTF-8 content assembly directly from pinned local Git objects; no working-file materialization or model prompt composition.
- One purpose-specific Codex CLI Adapter implementation; no general model-runtime abstraction.
- No adopted public schemas or contracts; the implemented contract is explicitly experimental `v0`.
- Accepted `main` includes explicit bounded local Instance-memory checkpoint and exact resume. Autonomous memory selection remains unimplemented.
- No message repository or transport implementation.
- GPL-3.0-only license and central licensing declaration are present; the original planning handoff remains unchanged historical provenance.
- Accepted `main` is `5575a6e7cf6daa3b4b97b5845beaa0380db3a086`, integrating the reviewed Instance-memory synchronization/recovery slice. Derive unintegrated work-branch commits from Git.
- No `index.html` or website exists. The future License-tab acceptance requirement is approved in `LICENSING.md` but unimplemented.
- One historical live `codex-cli 0.153.4` / `gpt-5.6-luna` invocation used exact source State `be1322c10287bafce9dc13925dcc6629a6088afe`, selected only `LICENSING.md`, and pinned Adapter State `bf6a098cb01843ea1b99556e7cf7ff7b4530531c:peoplebot/adapters`. The direct process exited zero, but its output failed the then-current response validator. The resulting Execution truthfully records `failed` / `adapter.response_invalid`, unknown usage, released admission, and exact local admitted-start/terminal evidence. No answer was accepted and no retry occurred. Its preserved unchanged historical summary is `docs/examples/read-only-licensing-live-result.json`; no retrospective stage diagnosis is inferred.
- The memory proof uses synthetic repositories and no model invocation. Its eight focused memory tests cover fresh-process resume, changed/unchanged descendants, Instance and Blueprint isolation, stale/symbolic/indeterminate ref preservation, busy admission, terminal-persistence failure after a saved checkpoint, checkout preservation, UTF-8 bounds, and missing promised objects with no fetch or worktree creation.
- On native Windows the implementation passes the 23-test memory/provenance affected set and all 110 repository tests with resource warnings treated as errors. Compilation succeeds on Python 3.12.14 with Git 2.53.0.windows.3. Final integrity, immutable-file, metadata, and synchronization results belong in the implementation handoff.
- Current correction after reviewed commit `949a63ab9c80dc2e152eebedfd636fb19406d68a` addresses checked-out memory branches and partial-State retention after record-construction failure. Final validation status must be derived from the latest commit and its handoff rather than inferred from this document.
- The completed memory correction compiles, passes five direct new regressions and all 28 memory/provenance focused tests, and passes all 115 repository tests on native Windows with resource warnings fatal. Git integrity, diff whitespace, documentation anchors, immutable licensing/package/planning/historical-artifact comparison, and the fresh-process save/resume demonstration pass. The exact review commit and synchronization evidence belong in the final handoff.
- Settled separate-environment alpha requirements, accepted explicit memory synchronization/recovery behavior, and the synthetic setup/adoption review target are recorded in `docs/planning/separate-environment-alpha.md`. No external NormsExchange resource or live GitHub runtime-memory operation has been created.
- Accepted synchronization/recovery commit `5575a6e7cf6daa3b4b97b5845beaa0380db3a086` is integrated on `main`. The unintegrated `codex/alpha-bootstrap` branch composes a deterministic root setup, narrow compatible framework adoption under Instance admission/provenance, and exact fresh-process resume for synthetic A/B fixtures. Its focused correction after reviewed commit `f69967e95d763cd51323a6861fa8d96552dcb09b` is not accepted for integration until ChatGPT reviews the final pushed commit.
- The alpha fixture child now uses the established bounded process-owner path: ownership begins immediately after spawn, one deadline covers prompt delivery/output/execution, and confirmed child shutdown plus worker joins precede ordinary admission release. Unresolved shutdown retains exact process and admission authority for explicit recovery without replacing the original interruption. This deliberately reuses `docs/contracts/read-only-adapter-v0.md` **Bounds, deadline, and process lifetime** / **Reusable Adapter lessons** and `docs/contracts/execution-provenance-v0.md` **Ordering and lifecycle** / **Reusable provenance lessons**.
- A record-construction failure after compatible selection publication does not recast adoption as a pre-publication failure. A constructible failed record has null `resulting_state`, code `alpha.record_failed_after_adoption`, and the exact selection State as its recoverable partial-State artifact; persistent record failure leaves the returned adoption and incomplete start evidence separate, without rollback, retry, or fabricated terminal evidence. This applies the existing partial-State reporting convention from `docs/contracts/state-execution-v0.md` and the analogous memory rule in `docs/contracts/instance-memory-v0.md`.
- The focused alpha correction passes all eight alpha tests, all 41 Adapter/provenance affected tests, and all 162 repository tests on native Windows with resource warnings fatal. Compilation succeeds on Python 3.12.14 with Git 2.53.0.windows.3. Final integrity, immutable-file, metadata, and remote synchronization results belong in the implementation handoff.
- Synthetic tests cover initial and fast-forward synchronization, hostile defaults, local/global URL-rewrite refusal, full tip/history tree validation, destination ambiguity/divergence, timeout/disconnect reconciliation, late record failure with exact recovered-State retention, transport setup failure with truthful ref retention, pipe-holding descendant ownership, busy admission, object-only retrieval, dangling symbolic owner/quarantine refusal, fresh-checkout exact UTF-8 recovery, guarded local fast-forward, explicit continuation after uncertain recovery, transaction-guarded owner/quarantine replacement, atomic cleanup preservation, checked-out/newer/conflicting State, invalid remote content, competing ownership, and preservation of local/remote unrelated surfaces. On native Windows, all 39 focused synchronization/recovery tests, all 15 provenance transaction tests, and all 154 repository tests pass with resource warnings fatal; compilation succeeds on Python 3.12.14 with Git 2.53.0.windows.3. Exact final commit synchronization belongs in the implementation handoff.
- No live GitHub runtime memory, model, NormsExchange resource, message, schedule, Blueprint maintenance workflow, or public release was created. Attempt/terminal evidence remains local and memory synchronization is not complete backup.
- Remaining supervised-alpha gates are real GitHub runtime-memory transport with externally managed credentials, reviewed release publication/adoption, separate NormsExchange provisioning, and a bounded project-task Adapter.
- Accepted alpha-bootstrap commit `caf28931017e4b002f5dd4d3d9c7e595826a5c30` is integrated on `main`. The unintegrated `codex/release-a-packaging` branch prepares ordinary dependency-free Python wheel/source packaging as version `0.1.0a1`; final artifact identity and validation must be derived from its generated evidence and implementation handoff.
- Release-candidate preparation is not release publication. The repository remains private, candidate artifacts remain local, and no tag, GitHub release, visibility change, consuming environment, runtime memory, or NormsExchange resource is authorized or created by this slice.
- Candidate packaging uses the standard setuptools build backend, explicitly packages the versioned Adapter configuration, carries `LICENSE` and `LICENSING.md` as installed license metadata, and includes source, tests, relevant configuration, contracts, and operating/release documentation in the source distribution. It adds no runtime dependencies. Validation builds both artifacts from clean committed State and exercises the wheel from an unrelated directory and fresh virtual environment; exact commit, tool versions, inventories, sizes, digests, and final test evidence remain in the adjacent generated candidate evidence and handoff rather than creating a self-referential commit.
- Next bounded action after a pushed candidate is ChatGPT read-only review of the exact packaging commit and artifact evidence. Integration and publication each require later explicit authorization.

## Repository-guidance retrieval check

This is a repository-guidance retrieval check, not a fresh-model test or implemented automatic learning:

- License and scope: `LICENSING.md` → **PeopleBot Licensing**, **Scope boundaries**.
- Creator acknowledgment and historical coverage: `LICENSING.md` → **Licensing Declaration — September 7, 2026**.
- Future website License tab: `LICENSING.md` → **Future website acceptance requirement**.
- Cleanup ownership and initial-disposability lesson: `docs/contracts/context-preparation-v0.md` → **Safe cleanup and failure**, **Reusable cleanup lessons**.
- Explicit useful context retrieval: `docs/contracts/context-assembly-v0.md` → **Inputs and selection**, **Content and encoding**, **Local-only behavior and failures**.
- Single-Execution admission: `docs/contracts/instance-admission-v0.md` → **Atomic acquisition and immediate rejection**, **Interruption boundary**, **Reusable admission lessons**.
- Durable admission/Execution evidence: `docs/contracts/execution-provenance-v0.md` → **Ordering and lifecycle**, **Records and completion meaning**, **Git-native local persistence**, **Failure semantics**, **Reusable provenance lessons**.
- Local Instance-memory checkpoint and exact resume: `docs/contracts/instance-memory-v0.md` → **Identity and inputs**, **Git layout and exact State**, **Execution lifecycle and interruption boundary**, **Exact resume**, **Reusable lessons**.
- Separate-environment supervised alpha and synchronization proposal: `docs/planning/separate-environment-alpha.md` → **Settled environment boundary**, **Supervised-alpha boundary**, **Proposed next slice**, **Remaining connections for the first NormsExchange task**.
- Exact synchronization and recovery experiment: `docs/contracts/instance-memory-synchronization-v0.md` → **Explicit authority and binding**, **Destination resolution and inspection**, **Outcomes and reconciliation**, **Fresh-checkout recovery**.
- Synthetic setup and compatible adoption: `docs/contracts/alpha-bootstrap-v0.md` → **Deterministic environment setup**, **Narrow fixture compatibility rule**, **Admission, publication, and failure**, **Fresh-process resume**.

Automatic procedure retrieval, promotion, and learning remain unimplemented. The current mechanism is stable repository guidance plus deliberate targeted reading.
