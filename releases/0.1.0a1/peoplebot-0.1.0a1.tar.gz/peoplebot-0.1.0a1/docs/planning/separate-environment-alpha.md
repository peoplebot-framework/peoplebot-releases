# Separate-Environment Supervised Alpha

Status: settled alpha requirements, an accepted synchronization/recovery experiment,
and a synthetic setup/adoption experiment pending review. None is an accepted public
contract or proof of real GitHub/NormsExchange isolation.

## Settled environment boundary

NormsExchange starts in a sovereign environment separate from PeopleBot framework
development. It has its own GitHub identity and repositories, separately configured
Codex installation/runtime and authentication context, Instance identities, memory,
project history, and credentials. It consumes an explicitly pinned PeopleBot
framework version as a dependency. No NormsExchange Instance or project memory is
created inside the PeopleBot development environment. This supersedes any earlier
proposal to host the first NormsExchange Instance in that development environment.

No NormsExchange account, repository name, credential, or first project task is
selected here. Creating or mutating those external resources requires a later
explicit instruction.

A new sovereign environment may begin with any supported agent type. An Architect
is the preferred setup default because it can maintain the environment and its
authorized local Blueprints, but an Architect is not a mandatory dependency for
every run. Bootstrap is deterministic: adopt a pinned PeopleBot release, reviewed
Blueprint States, and versioned setup commands rather than reconstructing the
framework from conversation.

The upstream PeopleBot Architect maintains PeopleBot releases. A local Architect
has maintenance authority only for its own authorized environment and local
Blueprints, deliberately adopts reviewed upstream changes, and gains no automatic
write authority to the upstream repository. Architect runs are manually initiated
by default. Ordinary agent types have framework and Blueprint maintenance authority
disabled unless an owner explicitly delegates it.

An owner may deliberately create an independent framework fork. That decision must
preserve canonical origin and applicable license notices, record the divergence,
and check compatibility before later upstream adoption. An ordinary task
instruction cannot silently create or authorize such a fork.

## Supervised-alpha boundary

The usable alpha may use manual launch, explicit context selection, explicit
checkpoint content, and manually initiated synchronization and framework-update
commands. It must nevertheless implement and test Git synchronization rather than
relying on ad hoc pushes. Synchronization must:

- target the owning environment's explicitly configured repository and exact refs;
- distinguish local-only, remotely verified, failed, and uncertain outcomes;
- preserve local progress after network or authentication failure;
- refuse conflicts without force-pushing or overwriting remote history;
- reconcile an uncertain remote outcome before retry; and
- demonstrate recovery in a fresh checkout in the same owning environment after
  the original Execution has stopped.

Pushing a PeopleBot framework branch does not synchronize Instance memory or local
Execution-evidence refs.

Framework adoption and Instance-memory synchronization are separate. Executions
finish on their pinned framework, Adapter, and Blueprint versions. Compatible
adoption preserves Instance identity and memory; incompatible adoption requires an
explicit migration, and update failure preserves the prior usable State. Before
broader onboarding, demonstrate release A installation, Instance creation, progress
save and synchronization, compatible release B adoption, and resume of the same
Instance from intact memory.

## Implemented experiment: explicit memory synchronization and recovery

The accepted implementation remains local, manual, and specific to one
Instance-memory ref. Its immutable requests/results expose two operations:

- `synchronize_instance_memory(request)` publishes one exact local memory State;
- `recover_instance_memory(request)` retrieves and verifies one exact remote memory
  State into a fresh checkout without starting an agent task.

The supported public wrappers run both operations under the existing
Instance admission/provenance lifecycle. A sanitized synchronization observation is
stored with local terminal evidence, while the transport implementation remains a
thin deterministic collaborator. Neither operation invokes a model.

The request includes repository identity, environment and Instance identity,
adopted Blueprint State, exact local memory State, derived source and destination
refs, an explicit remote name, the single expected resolved push URL, expected
remote State or explicit absence, and one bounded deadline. Recovery additionally
pins the expected remote commit. Its exact v0 field names remain experimental.

The caller/environment explicitly authorizes one pinned baseline and all
history reachable from it for this destination. Later checkpoints are accepted only
when they form the supported non-merge Instance-memory lineage above that baseline.
Matching names, repository privacy, or inspecting only the current memory tree does
not establish publication authority.

The result identifies the attempted local State, observed destination and ref,
remote observation when available, disposition (`local_only`, `remote_verified`,
`failed`, or `uncertain`), and classified reason. Returned observations, local Git
records, and verified remote state remain distinct. No unavailable remote or usage
fact is invented.

### Transport and ref safety

Resolve the named remote's push URLs through Git and require exactly one result that
matches the request's expected destination. Do not assume `origin`, equate fetch and
push URLs, or trust a remote alias as destination evidence. Invoke Git with an
explicit remote and one fully spelled source-to-destination refspec, disabling
follow-tags and repository hooks. Do not use default, wildcard, mirror, or configured
push refspecs, force, force-with-lease, or history rewriting.

Before transport, verify the local ref still equals the exact request State, its
metadata binding is valid, it is not checked out for changed publication, and the
remote observation equals the expected commit or explicit absence. A normal
fast-forward push may proceed only after those checks. A rejection is a classified
conflict and leaves local State intact.

Only the single `refs/heads/peoplebot/instances/v0/...` memory ref is in this first
slice. `refs/peoplebot/attempts/v0/...` terminal/admission evidence remains local.
Synchronizing it later needs a separate retention, privacy, and reachability
decision.

### Reachability and uncertain outcomes

Git transfers the object closure reachable from the selected memory commit, not
only `memory.json` and current item blobs. The accepted v0 request therefore pins
an explicitly authorized baseline and validates every post-baseline commit as the
strict supported non-merge memory lineage before publication. It refuses when the
expected remote State is outside that lineage or any transferred post-baseline tree
contains undeclared or invalid content. Broader baseline authorization and remote
history policies remain unresolved beyond this bounded operation.

A timeout, disconnect, or unreadable push result is `uncertain`, never failed or
verified merely from local output. Preserve the exact request and local State. A
separate reconciliation observation must query the exact remote ref: equality with
the attempted commit verifies the current remote ref value; observing the known
prior value does not prove publication never occurred; another value requires
deliberate reconciliation rather than blind retry; unavailable inspection remains
uncertain.
No automatic retry follows an uncertain result.

### Recovery boundary

Fresh-checkout recovery runs only after the original Execution is known stopped and
under the owning environment's same Instance admission boundary. It explicitly
fetches the one expected memory ref/commit into a quarantine ref, verifies the exact
commit, repository/environment/Instance/Blueprint metadata binding and object
availability, then creates or guardedly advances only the local Instance-memory ref.
It invokes no model and does not itself enable a second live Execution. Context is
retrieved afterward through `assemble_instance_memory_context` from the pinned State.

A fresh checkout in the same owning environment is not a new environment. Moving
memory into another sovereign environment creates a new Instance and remains
outside this slice. Recovery retains uncertain quarantine State for deliberate
inspection and does not force replacement, prune refs, or infer task/external-effect
safety from a Git observation.

### Reuse and deterministic tests

Reuse `StateRef`/`resolve_state`, `instance_memory_ref`, memory metadata validation,
the prepared exact-ref transaction, Instance admission, Execution provenance, and
bounded sanitized Git subprocess conventions. Do not build authentication,
permissions, transport queues, or a parallel synchronization service.

Use isolated working and bare repositories to test exact initial/fast-forward push,
explicit-ref-only behavior despite hostile defaults/refspecs, differing fetch/push
URLs, multiple push-URL refusal, remote divergence, local movement, authentication
or transport failure, timeout followed by each reconciliation outcome, reachability
inspection, no hooks/tags/attempt-ref publication, and fresh-checkout recovery with
busy-Instance refusal. A later separately authorized test may validate real GitHub
transport and externally managed credentials.

## Synthetic setup/adoption experiment

The `codex/alpha-bootstrap` experiment composes exact setup, accepted memory
checkpoint/synchronization/recovery, compatible adoption, and fresh-process resume
against isolated local working and bare repositories. Its A and B are explicitly
fixtures, not releases. It retains the exact A Blueprint State and memory lineage,
and accepts B only when Git ancestry plus unchanged exact Blueprint/interface
objects establish the narrow fixture rule. See
`docs/contracts/alpha-bootstrap-v0.md` for the review target and limitations.

## Remaining connections for the first NormsExchange task

1. Provision and verify the separate environment, GitHub identity/repositories,
   local runtime root, Codex installation, and independent authentication context.
2. Publish and explicitly adopt a reviewed PeopleBot release A by exact version and
   commit; do not consume an unreviewed development branch.
3. Create the NormsExchange Instance and its repository/memory configuration inside
   that owning environment.
4. Validate real GitHub memory transport using externally managed credentials and
   the accepted bounded synchronization/recovery path.
5. Replace the licensing-specific demonstration Adapter with a minimal project-task
   Adapter whose context, model/runtime configuration, filesystem/tool permissions,
   external-action authority, and terminal provenance are explicit and pinned.
6. Define the first supervised task and its permission boundary without granting
   credentials or authority through names or prose.
7. Repeat the synthetic A-to-B proof using reviewed published releases and the
   separately provisioned environment; define migration behavior before any
   incompatible update.

Scheduling, automatic relevance inference, automatic checkpoint selection,
Blueprint maintenance automation, messaging, UI, additional providers, and
non-Windows support remain outside this alpha milestone.
