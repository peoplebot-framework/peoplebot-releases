# PeopleBot Repository Guidance

These instructions apply to this repository.

## Authority and scope

- Follow the latest explicit user instruction, then the settled requirements in `PROJECT_STATE.md`.
- Distinguish settled requirements, implementation proposals, experiments, and unresolved choices. Never promote one category into another silently.
- This repository is a clean PeopleBot V2 rebuild. Do not inspect, fetch, clone, restore, import, migrate, modify, or use V1 for design guidance.
- ChatGPT is used for discussion and read-only review; Codex performs implementation, validation, commits, and repository writes unless Ray explicitly changes that workflow.

## Continuation protocol

- At session start or resumption, verify repository identity, branch/upstream, and exact working State from Git. Then read this file, `PROJECT_STATE.md`, and only the task-relevant linked contracts or procedures.
- Before edits, report a concise context readback with the current goal, full starting commit, applicable settled decisions, genuinely open questions, bounded next action, and repository locations. This is feedback, not another permission gate.
- At a meaningful finish, block, or yield, update the compact current-state surface with results, decisions, remaining issues, work branch, and next action. Commit useful authorized progress and synchronize at meaningful boundaries.
- Apply the refill-aware capacity/stopping policy and Instance-memory decisions in `PROJECT_STATE.md`; detailed Adapter lifetime and evidence lessons live in `docs/contracts/read-only-adapter-v0.md`.
- Derive the current commit identity from Git. Do not create a commit-update loop by trying to embed a commit's own hash inside itself.
- Keep accepted `main` and unintegrated working State distinguishable. A decision committed only on a work branch has not landed on `main`.
- Promote reusable lessons into the relevant stable contract or procedure and regression tests. Extend adopted knowledge by default and preserve valid earlier lessons; temporary work branches are not lasting knowledge lineages.
- Use stable paths and logical procedure identities for discovery, while pinning full commits for the State actually used by an Execution. Adoption of upstream changes remains deliberate.
- Do not routinely reload the complete planning handoff, instruction prompts, raw transcripts, or full history. Retrieve targeted references and relevant Git deltas.
- If access is blocked, report the exact boundary and preserve local progress. Do not retry indefinitely, recreate the project, search for secrets, or ask Ray to reconstruct decisions already committed here.
- Committed State does not automatically preserve uncommitted index or working-tree content; inspect and protect those surfaces separately.

## Architectural invariants

- Preserve exactly five core primitives: Blueprint, Instance, State, Message, and Execution.
- A Blueprint defines a reusable agent type, an Instance is one concrete agent created from that type, and an Execution is one bounded run of that Instance.
- Treat roles as metadata or Blueprint/Instance descriptions.
- Treat runtime Adapters as thin deterministic infrastructure, not another primitive.
- Treat environment as the sovereign hosting and ownership context, not another primitive.
- Identify exact State with repository identity plus a full Git commit and optional path. Never claim a mutable branch or logical name is exact State.
- Bound each Execution to one invocation or work attempt and record its exact inputs, adopted dependencies, responsible Instance, outputs, resulting State or terminal outcome, and available usage provenance.
- Prefer Git's existing commits, branches, worktrees, merges, ancestry, provenance, recovery, permissions, and synchronization over custom substitutes.
- Use deterministic software for known traversal, resolution, selection, diffing, validation, transport, and bookkeeping. Use AI for inference.
- Project only relevant context into a model. Keep complete appropriate artifacts addressable within their permitted privacy boundary.
- For explicit read-only content retrieval, apply the deterministic behavior and limits in `docs/contracts/context-assembly-v0.md`; do not substitute mutable working files for pinned Git objects.
- For explicit local Instance-memory checkpoint and exact resume, apply `docs/contracts/instance-memory-v0.md`; preserve the separation among a pinned memory State, its mutable discovery ref, terminal evidence, and remote synchronization.
- For explicit single-Instance memory synchronization and same-environment recovery, apply `docs/contracts/instance-memory-synchronization-v0.md`; validate the complete authorized post-baseline lineage, bind every transport step to one rewrite-free destination, and retain uncertain quarantine/effect evidence without automatic retry.

## Ownership and maintenance boundaries

- Only an Instance's owning sovereign environment executes it and advances its canonical State. Copying to another environment creates a new Instance; credentials, permissions, private context, and standing authority do not transfer.
- Admit at most one active Execution per Instance through one environment-local atomic mechanism shared by every launch path. A concurrent request exits immediately with a classified outcome and performs no model call, waiting, queueing, polling, or automatic retry. Admission implementations follow the [experimental lifecycle and reusable lessons](docs/contracts/instance-admission-v0.md#reusable-admission-lessons).
- Release execution ownership only after work has actually stopped. After interruption, preserve recoverable State and establish that the earlier execution cannot continue; timer expiry, callback return, or an exception alone is not proof.
- Identity-specific branches store each Instance's context and progress. Branch names identify storage, not authority. Parallel agents of one type are separate Instances.
- The framework architect is the sole framework/Blueprint maintainer by default, is started manually by Ray, and has no default schedule or background invocation. Maintenance authority for new agent types is off unless explicitly delegated.
- Ordinary agents autonomously maintain authorized task State, context, and procedures. Improvement proposals do not trigger architect work, and running an Instance does not require Blueprint review or rewriting.
- Shared framework integration retains one designated owner. Active executions keep pinned adopted versions; compatible updates may be adopted at boundaries, while incompatible changes require an explicit migration procedure.
- Preserve owner-publishes/authorized-peers-read messaging. The environment deterministically serializes Instance-composed messages to its outbound branch, preserves request identity and outcomes, and reconciles uncertain external effects before retrying.
- Git rollback does not undo external actions. Never infer authority from agent names, branch names, or prose, and never infer execution status from prose.

## Knowledge evolution

- Extend the adopted procedure lineage by default and retain still-valid knowledge.
- Create separate knowledge lineages only for genuine divergence, preserve their ancestry, and allow deliberate reconciliation of compatible learning.
- Pin the exact resolved procedure commit used by every Execution.
- Keep temporary Execution branches/worktrees conceptually separate from lasting knowledge lineages.
- Do not invent the precise divergence decision mechanism before implementation evidence requires it.
- Never treat copied knowledge as copied authority, credentials, private memory, transcripts, private reasoning, or standing permission.

## Git and repository safety

- Work on isolated branches or worktrees when concurrency requires it and integrate through normal Git mechanisms.
- Commit durable results at meaningful Execution boundaries. Avoid timer-based checkpoint churn.
- Preserve unrelated work and established history. Never force-push or destructively rewrite shared history.
- Verify repository identity, branch, upstream, exact commits, and remote synchronization before reporting success.
- Before cleanup or rollback code, apply the [ownership and preservation lessons](docs/contracts/context-preparation-v0.md#reusable-cleanup-lessons); uncertain state stays recoverable.
- Do not add another database or subsystem for facts Git and small addressable records already provide.

## Security and truthful reporting

- Never commit credentials, tokens, cookies, private keys, authentication caches, private transcripts, private reasoning, customer data, or unrestricted raw operational data.
- Keep permissions and credentials externally managed through GitHub and the hosting environment.
- Report only verified results. Mark unavailable usage or external state as unknown; never invent measurements or claim remote success without checking it.
- Treat access denial as a bounded blocked or failed outcome rather than searching for secrets or retrying indefinitely.

## Origin and licensing

- PeopleBot is licensed `GPL-3.0-only`. Preserve `LICENSE`, the central declaration and creator acknowledgment in `LICENSING.md`, exact provenance to canonical PeopleBot, applicable legal notices, and contributor attribution.
- Do not add an advertising, badge, repeated-branding, trademark, contributor-assignment, CLA, or DCO requirement without a later explicit decision.
- The future `index.html` License-tab acceptance requirement is recorded in `LICENSING.md`; it is approved future work, not authorization to build or publish a website in the current slice.

## Historical founding constraint

- The founding commit remains documentation/configuration only. Later explicit decisions authorized the current experimental code and GPLv3-only license; preserve the immutable planning handoff instead of rewriting historical guidance.
