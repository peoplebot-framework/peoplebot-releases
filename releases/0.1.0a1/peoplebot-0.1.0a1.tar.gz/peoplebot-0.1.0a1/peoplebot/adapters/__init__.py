"""Thin, versioned runtime adapters."""

from .codex_read_only import (
    AdapterObservation,
    CodexReadOnlyAdapter,
    CodexReadOnlyConfiguration,
    DirectProcessDisposition,
    LicensingAnswer,
    ProcessOwnershipUnresolved,
    ReadOnlyExecutionResult,
    run_read_only_licensing_execution,
)

__all__ = [
    "AdapterObservation",
    "CodexReadOnlyAdapter",
    "CodexReadOnlyConfiguration",
    "DirectProcessDisposition",
    "LicensingAnswer",
    "ProcessOwnershipUnresolved",
    "ReadOnlyExecutionResult",
    "run_read_only_licensing_execution",
]
